package com.example.pc.projekt.Models;

import android.graphics.Bitmap;

/**
 * Created by pc on 2017-05-25.
 */

public class Attachement {
    public String path;
    public int id;
    public Bitmap photo;
}
