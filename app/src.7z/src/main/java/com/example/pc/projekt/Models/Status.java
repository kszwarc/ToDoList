package com.example.pc.projekt.Models;

/**
 * Created by pc on 2017-05-25.
 */

public class Status {
    public String status;
    public int id;
}
